public class Fibonacci
{
   public static void main( String[] args )
   {
      IntBag bag = new IntBag();
      
      int first_Number = 0;
      int second_Number = 1;
      int num = 40;
      
      bag.addToEnd( first_Number );
      bag.addToEnd( second_Number );

      
      for( int i = 2; i < num; i++)
          bag.addToEnd( bag.getValueAtIndex(i-1) + bag.getValueAtIndex(i-2) );
      
      System.out.println( "First " + bag.size() + " terms of Fibonacci Numbers:" );
      System.out.println( bag.toString() );
   } //end main method
} //end class
