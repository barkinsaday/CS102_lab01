import java.util.*;
public class Menu
{
   public static void main(String[] args)
   {
      Scanner scan = new Scanner(System.in);
      
      IntBag bag = new IntBag();
      
      boolean exit = false;
      
      int op = 0;
      
      while( !exit )
      {
         System.out.println( "------------------------------------------------------------------------------------------------------------------------" );
         System.out.println( "1) Create a new collection (any previous values are lost!" );
         System.out.println( "2)Read a set of positive values into the collection (use 0 to indicate all the values have been entered" );
         System.out.println( "3)Print the collection" );
         System.out.println( "4)Add a value to the collection at a spesific location" );
         System.out.println( "5)Remove the value from collection at a spesific location" );
         System.out.println( "6)Remove all instance of values from collection" );
         System.out.println( "7)Quit the program" );
         System.out.println( "Please choose the operation you want to do" );
         System.out.println( "------------------------------------------------------------------------------------------------------------------------" );
         
         op = scan.nextInt();
         
         if( op == 1 )
            bag = new IntBag();
         
         if( op == 2 ) 
         {
            int value;
            do
            {
               System.out.println( "Please enter the value you want to add ( enter 0 if you are done adding values)" );
               value = scan.nextInt();
               bag.addToEnd( value );
            }
            while( value != 0);
         }
         
         if( op == 3 )
            System.out.println( bag.toString() );
         
         if( op == 4 )
         {
            System.out.println( "Enter the value you want to add" );
            int value = scan.nextInt();
            System.out.println( "Enter the index of where you want to enter the value" );
            int index = scan.nextInt();
            
            bag.addToIndex( index, value );
         }
         
         if( op == 5 )
         {
            System.out.println( "Please enter the index(location) of the value you want to remove" );
            int index = scan.nextInt();
            
            bag.removeAtIndex( index );
         }
            
         if( op == 6 )
         {
            System.out.println( "Please enter the value that will be removed from collection (from all locations" );
            int value = scan.nextInt();
            
            bag.removeAll( value );
         }
         
         if( op== 7 )
         {
            exit = true;
            System.out.println( "Goodbye..." );
         }   
      }//end loop
   }//end main
}//end class