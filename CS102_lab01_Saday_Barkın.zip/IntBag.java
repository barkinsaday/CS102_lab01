/*@author: Bark�n Saday
 * @date: 05.10.2020
*/
public class IntBag
{
   //properties
   int[] bag;
   
   //consturactor
   public IntBag()
   {
      bag = new int[]{ -1, -1, -1, -1,};
   }
   
   //methods
   
   
   /*
    * @param: int value that will be added to the end of the IntBag
    * @return: void
    * Increses the size of IntBag by 1 if there is no room for the new value
   */
   public void addToEnd( int value )
   {
      boolean check = false;
      for( int i = 0; i < bag.length && !check; i++ )
      {
         if( bag[i] < 0 )
         {
            bag[i] = value;
            check = true;
         }
      }
      if( !check )//if the bag is full
      {
         int[] temp = new int[ bag.length + 1 ];
         for( int i = 0; i < bag.length; i++ )
         {
            temp[i] = bag[i];
         }
         bag = temp;
         bag[ bag.length - 1] = value;
      }
   }
   
   
    /*
     * @param: -
     * @retun: String that contains the values inside the IntBag
     * Displays the integers inside the IntBag
   */
   public String toString()
   {
      String result;
      result = "";
      
      for( int i = 0; i < bag.length; i++ )
         if( bag[i] > 0 )
            result = result + bag[i] + " ";
      
      return result;
   } 
   
   
   /* 
    * @param: int index, the index of where the value will be added to
    * @param: int value, the integer that is added to IntBag
    * @return: void
   */
   public void addToIndex( int index, int value )
   {
      if( index < 0 || index >= bag.length ) //checks if the index is a valid number
         System.out.println( "Please choose a valid index" );
      
      else
      {
         int temp[] = new int[ bag.length + 1 ];
         
         for( int i = 0; i < index; i++ )//copy the part before the index
            temp[i] = bag[i];
         
         temp[index] = value;//puts the given value at the given index
         
         for( int i = index+1; i < bag.length + 1; i++ )// copy the part after the index
            temp[i] = bag[i - 1];
         
         bag = temp; 
      }
   }
   
   /*
    * @param: int index, the index of the element that will be removed from IntBag
    * @retun: void
   */
   public void removeAtIndex( int index )
   {
      if( index < 0 || index >= bag.length )
         System.out.println( "Please choose a valid index" );
      
      else
      {
         int[] temp = new int[ bag.length-1 ];
         
         for( int i = 0; i < index; i++ )//copy the part before the index
            temp[i] = bag[i];
         
         for( int i = index; i < bag.length-1; i++ )//removing the value at index and than copying up to that index
             temp[i] = bag[i+1];
         
         bag = temp;  
      }
   }
   
   
   /*
    * @param: int value, the value of the integer that will be checked if it exist or not 
    * @return: boolean exist, true if IntBag contains the "value", false otherwise
   */
   public boolean doesItExist( int value )
   {
      boolean exist = false;
      
      for( int i = 0; i < bag.length; i++ )
      {
         if( value == bag[i] )
         {
            exist = true;
            i = bag.length+1; //ends the loop
         }
      }
      return exist;
   }
   
   
   /*
    * @param: -
    * @retun: int validSize, the number of elements inside the IntBag that is non-zero
   */
   public int size()
   {
      int validSize = 0;
      for( int i = 0; i < bag.length; i++ )
         if( bag[i] >= 0)
            validSize = validSize + 1;
      return validSize;
   }
   
   /*
    * @param: int index, index of the value that will be returned
    * @return: returns the integer at the given index of IntBag, returns -1 if index is not valid
   */
   public int getValueAtIndex( int index )
   {
      if( index < 0 || index >= bag.length )
      {
         System.out.println( "Please choose a valid index! ");
         return -1;//as a sentinal
      }
      
      else
         return bag[index];
   }
   
   /*
    * @param: int value, the value to be removed from IntBag at all indexes
    * @return: void
   */
   public void removeAll( int value )
   {
      for( int index = 0; index < bag.length; index++ )
      {
         if( bag[index] == value )
         {
            int[] temp = new int[ bag.length-1 ];
            
            for( int i = 0; i < index; i++ )//copy the part before the index
               temp[i] = bag[i];
            
            for( int i = index; i < bag.length-1; i++ )//removing the value at index and than copying up to that index
               temp[i] = bag[i+1];
            
            bag = temp;
            index= 0;
         } 
      }
   }
}//end class